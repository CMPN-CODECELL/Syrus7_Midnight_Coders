# TradeMint - Automated Email P&L Statement Engine

A completely self-contained, single-file implementation of the **TradeMint Daily Profit & Loss (P&L) Statement & Email Alert Engine**.

---

## 📁 File Included
- **`email_model.py`**: A 100% standalone Python script with zero third-party dependencies (uses only standard Python libraries: `smtplib`, `email`, `datetime`, `json`, `argparse`).

---

## ⚡ Quick Test (Command Line)

To test sending a real email statement immediately, run:

```bash
python email_model.py your_email@gmail.com
```

### With Custom Credentials:
```bash
python email_model.py recipient@gmail.com --user your_email@gmail.com --password your_16_digit_app_password
```

---

## 💻 How to Use in Your Python Code

```python
from email_model import EmailService

# Initialize the service
service = EmailService(
    smtp_user="your_email@gmail.com",
    smtp_password="your_16_digit_app_password"  # Google App Password
)

# 1. Compile P&L and regulatory taxes
statement_data = service.build_pnl_statement_data(
    user_name="Trader",
    user_email="client@example.com",
    ucc="021-HACK342"
)

# 2. Dispatch real email with modern HTML design
result = service.send_pnl_statement_email(
    recipient_email="client@example.com",
    statement_data=statement_data
)

print(result["deliveryStatus"])  # DELIVERED
```

---

## 🚀 How to Manually Upload to GitHub

If you prefer to push or upload manually without using git commands:

### Method 1: Drag & Drop via GitHub Web UI
1. Open your repository on **[github.com](https://github.com)**.
2. Go to the branch you want (`main`).
3. Click **Add file** -> **Upload files**.
4. Drag and drop **`email_model.py`** into the box.
5. Write commit message: `Add email P&L alert model`.
6. Click **Commit changes**.

### Method 2: Git Terminal Commands
```bash
git add email_model.py
git commit -m "Add standalone email P&L alert model"
git push origin main
```
